﻿namespace Ex006
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, num2;
            float resposta;

            Console.WriteLine("Digite a primeira nota:");

            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Digite a segunda nota:");

            num2 = Convert.ToInt32(Console.ReadLine());

            resposta = (num + num2) % 2;
            
            Console.WriteLine("{0} + {1} = {2}", num, num2, resposta % 2);

        }
    }
}
